public interface StrategyRunner {
    void runForMinion(GameContext ctx);
}