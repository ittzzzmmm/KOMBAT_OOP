public enum TurnPhase {
    P1_BUY_HEX,
    P1_BUY_MINION,
    P2_BUY_HEX,
    P2_BUY_MINION,
    RUN_STRATEGY
}