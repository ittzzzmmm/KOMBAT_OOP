import java.util.Map;
import java.util.Objects;

public final class GameContext {

    private final GameState state;
    private final Minion self;
    private final int maxTicks;

    public GameContext(GameState state, Minion self, int maxTicks) {
        this.state = Objects.requireNonNull(state);
        this.self = Objects.requireNonNull(self);
        if (maxTicks <= 0) throw new IllegalArgumentException("maxTicks must be > 0");
        this.maxTicks = maxTicks;
    }

    public GameState state() { return state; }
    public Minion self() { return self; }
    public int maxTicks() { return maxTicks; }

    public PlayerId owner() { return self.owner(); }

    public long getVar(String name) {
        if (name == null || name.isBlank()) return 0L;

        Long special = readSpecial(name);
        if (special != null) return special;

        if (isGlobalName(name)) {
            return player().globalVars().getOrDefault(name, 0L);
        } else {
            return localVars().getOrDefault(name, 0L);
        }
    }

    public void setVar(String name, long value) {
        if (name == null || name.isBlank()) return;
        if (isReadOnly(name)) return;

        if (isGlobalName(name)) {
            player().globalVars().put(name, value);
        } else {
            localVars().put(name, value);
        }
    }

    private boolean isReadOnly(String name) {
        return switch (name) {
            case "row", "col",
                 "budget", "maxBudget", "spawnsLeft",
                 "opponent", "ally",
                 "random",
                 "nearby" -> true;
            default -> false;
        };
    }

    private Long readSpecial(String name) {
        return switch (name) {
            // position
            case "row" -> (long) self.pos().row;
            case "col" -> (long) self.pos().col;

            // economy/state
            case "budget" -> (long) Math.floor(player().budget());
            case "maxBudget" -> state.maxBudget();
            case "spawnsLeft" -> state.spawnsLeft(owner());

            // sensing/encoding (depends on your GameMap API)
            case "opponent" -> (long) state.map().encodeClosestOpponent(state, self.id());
            case "ally" -> (long) state.map().encodeClosestAlly(state, self.id());

            // rng
            case "random" -> (long) player().random0to999();

            // nearby requires direction parameter
            case "nearby" -> 0L;

            default -> null;
        };
    }

    // Prefer function form for nearby because it needs dir
    public long nearby(direction dir) {
        return state.map().encodeNearby(state, self.id(), dir);
    }


    private Player player() {
        return state.player(owner());
    }

    private Map<String, Long> localVars() {
        return self.localVars();
    }

    private static boolean isGlobalName(String name) {
        return Character.isUpperCase(name.charAt(0));
    }
}