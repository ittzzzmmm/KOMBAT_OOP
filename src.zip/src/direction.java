public enum direction {
    UP , UPRIGHT , DOWNRIGHT , DOWN , DOWNLEFT , UPLEFT;
}
